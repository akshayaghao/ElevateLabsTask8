package OnlineQuizApp;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class QuizApp {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        List<Question> quizQuestions = new ArrayList<>();

        

        List<String> optionsQ1 = new ArrayList<>();
        optionsQ1.add("A JavaScript library for building user interfaces");
        optionsQ1.add("A CSS framework");
        optionsQ1.add("A database system");
        quizQuestions.add(new Question("Q1. What is React.js?", optionsQ1, 1));

        List<String> optionsQ2 = new ArrayList<>();
        optionsQ2.add("Document Object Model");
        optionsQ2.add("Data Object Management");
        optionsQ2.add("Document Oriented Mapping");
        quizQuestions.add(new Question("Q2. What does DOM stand for in web development?", optionsQ2, 1));

        List<String> optionsQ3 = new ArrayList<>();
        optionsQ3.add("useState");
        optionsQ3.add("useVariable");
        optionsQ3.add("useChange");
        quizQuestions.add(new Question("Q3. Which React Hook is used for managing state?", optionsQ3, 1));

        List<String> optionsQ4 = new ArrayList<>();
        optionsQ4.add("React Native");
        optionsQ4.add("JSX");
        optionsQ4.add("Node.js");
        quizQuestions.add(new Question("Q4. What syntax does React use to write HTML inside JavaScript?", optionsQ4, 2));

        List<String> optionsQ5 = new ArrayList<>();
        optionsQ5.add("Virtual DOM updates only changed parts of the UI");
        optionsQ5.add("Virtual DOM refreshes the entire page");
        optionsQ5.add("Virtual DOM is a database in React");
        quizQuestions.add(new Question("Q5. Which is true about the Virtual DOM in React?", optionsQ5, 1));

        List<String> optionsQ6 = new ArrayList<>();
        optionsQ6.add("Facebook");
        optionsQ6.add("Google");
        optionsQ6.add("Microsoft");
        quizQuestions.add(new Question("Q6. Who developed React.js?", optionsQ6, 1));

        List<String> optionsQ7 = new ArrayList<>();
        optionsQ7.add("Single Page Application");
        optionsQ7.add("Server Page Application");
        optionsQ7.add("Standalone Page Application");
        quizQuestions.add(new Question("Q7. React is mainly used for building?", optionsQ7, 1));

        List<String> optionsQ8 = new ArrayList<>();
        optionsQ8.add("Component-based architecture");
        optionsQ8.add("Monolithic architecture");
        optionsQ8.add("Procedural architecture");
        quizQuestions.add(new Question("Q8. What type of architecture does React follow?", optionsQ8, 1));

        List<String> optionsQ9 = new ArrayList<>();
        optionsQ9.add("npm install react");
        optionsQ9.add("npm create react-app");
        optionsQ9.add("npx create-react-app");
        quizQuestions.add(new Question("Q9. Which command is used to create a new React app?", optionsQ9, 3));

        List<String> optionsQ10 = new ArrayList<>();
        optionsQ10.add("HTML + CSS");
        optionsQ10.add("JSX");
        optionsQ10.add("Java");
        quizQuestions.add(new Question("Q10. React uses which syntax extension for writing UI?", optionsQ10, 2));

        List<String> optionsQ11 = new ArrayList<>();
        optionsQ11.add("setState()");
        optionsQ11.add("updateState()");
        optionsQ11.add("changeState()");
        quizQuestions.add(new Question("Q11. In React class components, which method is used to update state?", optionsQ11, 1));

        List<String> optionsQ12 = new ArrayList<>();
        optionsQ12.add("Functional components");
        optionsQ12.add("Class components");
        optionsQ12.add("Both A and B");
        quizQuestions.add(new Question("Q12. React components can be created using?", optionsQ12, 3));

        List<String> optionsQ13 = new ArrayList<>();
        optionsQ13.add("It improves performance by reducing real DOM manipulations");
        optionsQ13.add("It slows down rendering");
        optionsQ13.add("It replaces JavaScript");
        quizQuestions.add(new Question("Q13. Why is Virtual DOM faster?", optionsQ13, 1));

        List<String> optionsQ14 = new ArrayList<>();
        optionsQ14.add("Hooks");
        optionsQ14.add("Props");
        optionsQ14.add("State");
        quizQuestions.add(new Question("Q14. Which feature allows passing data from parent to child components?", optionsQ14, 2));

        List<String> optionsQ15 = new ArrayList<>();
        optionsQ15.add("useEffect");
        optionsQ15.add("useData");
        optionsQ15.add("useAPI");
        quizQuestions.add(new Question("Q15. Which hook is used for side effects in React?", optionsQ15, 1));

        List<String> optionsQ16 = new ArrayList<>();
        optionsQ16.add("index.html");
        optionsQ16.add("App.js");
        optionsQ16.add("style.css");
        quizQuestions.add(new Question("Q16. In a React project, which file is the entry point?", optionsQ16, 1));

        List<String> optionsQ17 = new ArrayList<>();
        optionsQ17.add("Babel");
        optionsQ17.add("Webpack");
        optionsQ17.add("Both A and B");
        quizQuestions.add(new Question("Q17. Which tools are commonly used with React for transpiling and bundling?", optionsQ17, 3));

        List<String> optionsQ18 = new ArrayList<>();
        optionsQ18.add("Props are immutable");
        optionsQ18.add("Props can be changed by child");
        optionsQ18.add("Props are same as state");
        quizQuestions.add(new Question("Q18. Which is true about Props in React?", optionsQ18, 1));

        List<String> optionsQ19 = new ArrayList<>();
        optionsQ19.add("To generate random IDs");
        optionsQ19.add("To uniquely identify elements for efficient updates");
        optionsQ19.add("To encrypt data");
        quizQuestions.add(new Question("Q19. What is the use of keys in React lists?", optionsQ19, 2));

        List<String> optionsQ20 = new ArrayList<>();
        optionsQ20.add("React DOM");
        optionsQ20.add("React Router");
        optionsQ20.add("React Native");
        quizQuestions.add(new Question("Q20. Which library is used for navigation in React apps?", optionsQ20, 2));

  

        int score = 0;

        for (Question q : quizQuestions) {
            q.displayQuestion();

            int userAnswer = 0;
            boolean validInput = false;

            while (!validInput) {
                System.out.print("Enter your answer (1-" + q.getOptionCount() + "): ");
                if (sc.hasNextInt()) {
                    userAnswer = sc.nextInt();
                    if (userAnswer >= 1 && userAnswer <= q.getOptionCount()) {
                        validInput = true;
                    } else {
                        System.out.println("Invalid choice. Please enter a valid option number.");
                    }
                } else {
                    System.out.println("Invalid input. Please enter a number.");
                    sc.next(); 
                }
            }

            if (q.isCorrect(userAnswer)) {
                System.out.println("Correct");
                score++;
            } else {
                System.out.println("Wrong");
            }
        }

     
        System.out.println("\n===== Quiz IS Over Now =====");
        System.out.println("Your Score: " + score + " / " + quizQuestions.size());

        if (score == quizQuestions.size()) {
            System.out.println(" Excellent! You got all correct!");
        } else if (score >= quizQuestions.size() / 2) {
            System.out.println("Good job!");
        } else {
            System.out.println("Keep practicing!");
        }

        sc.close();
    }
}
