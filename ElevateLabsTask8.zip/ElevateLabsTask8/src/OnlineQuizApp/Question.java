package OnlineQuizApp;

import java.util.List;

public class Question {
    private final String questionText;
    private final List<String> options;
    private final int correctOption; 

    public Question(String questionText, List<String> options, int correctOption) {
        if (options == null || options.isEmpty()) {
            throw new IllegalArgumentException("Options cannot be null or empty");
        }
        if (correctOption < 1 || correctOption > options.size()) {
            throw new IllegalArgumentException("correctOption must be between 1 and " + options.size());
        }
        this.questionText = questionText;
        this.options = options;
        this.correctOption = correctOption;
    }

    public void displayQuestion() {
        System.out.println("\n" + questionText);
        for (int i = 0; i < options.size(); i++) {
            System.out.println((i + 1) + ". " + options.get(i));
        }
    }

    public boolean isCorrect(int userAnswer) {
        return userAnswer == correctOption;
    }

    public int getOptionCount() {
        return options.size();
    }
}
